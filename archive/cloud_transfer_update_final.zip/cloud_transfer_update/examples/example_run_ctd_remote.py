from pathlib import Path
import sys

sys.path.append(str(Path(__file__).resolve().parents[1] / "integration"))

from bq_io import read_from_big_query, write_to_big_query
from orchestration import run_full_cloud_workflow

def main():
    result = run_full_cloud_workflow(
        dataset="ctd_remote",
        mode="lite",
        bronze_table_name="ctd_remote_bronze",
        read_from_bigquery=read_from_big_query,
        write_to_bigquery=write_to_big_query,
        config_root=Path(__file__).resolve().parents[1] / "configs",
        gapfill_scripts_root=Path(__file__).resolve().parents[1] / "gapfill",
        analysis_scripts_root=Path(__file__).resolve().parents[1] / "analysis",
    )
    print(result)

if __name__ == "__main__":
    main()
