# README_cloud_transfer_update.md

## Actualización del esquema de transferencia a la nube

Este documento redefine la estructura de integración con BigQuery para que sea compatible con el esquema modular actual, basado en dos etapas separadas: `gapfilling` y `analysis`. El objetivo es conservar el principio ya adoptado de separar estrictamente la lectura y escritura en BigQuery de la lógica científica del pipeline. En el diseño previo, la integración estaba organizada alrededor de una única función central que recibía un `DataFrame` y devolvía seis tablas persistibles. Ese patrón aparece tanto en el ejemplo de integración como en la documentación técnica vigente. fileciteturn10file0 fileciteturn10file3

## 1. Principio de diseño que se conserva

Se mantiene la separación estricta de responsabilidades. La capa analítica no debe leer desde BigQuery ni escribir en BigQuery por su cuenta. La capa de integración es la única responsable de leer tablas fuente, invocar funciones analíticas y escribir tablas destino. Ese principio ya estaba explícitamente establecido en la documentación entregada para la integración anterior y debe preservarse en la actualización. fileciteturn10file3turn10file4

## 2. Problema del diseño actual

La arquitectura actual de integración fue escrita para una sola función `transform_timeseries(df_raw, config)` que devuelve seis objetos persistibles: `df_transformed`, `df_psd`, `df_beta`, `df_fi`, `df_graph` y `df_regimes`. Ese patrón todavía está reflejado en el ejemplo mínimo de integración y en el pipeline modular anterior. fileciteturn10file0turn10file2 Sin embargo, el desarrollo reciente ya separó el trabajo en dos etapas distintas:

1. una etapa de `gapfilling` con sus propios scripts y configuraciones `lite` y `full`,
2. una etapa de `analysis` que consume la salida del gap filling y también tiene configuraciones `lite` y `full`.

Por lo tanto, el contrato de integración debe migrar desde una sola función central hacia un flujo de dos etapas.

## 3. Arquitectura objetivo

La arquitectura objetivo queda organizada así:

### Etapa S2, gap filling
Entrada:
- tabla bronze del dataset correspondiente

Salida persistible:
- tablas intermedias y de control del gap filling

### Etapa S3, analysis
Entrada:
- tabla gapfilled de S2
- tabla de segmentación de S2

Salida persistible:
- tablas analíticas finales para consulta, reportes y visualización

Esta actualización mantiene el desacoplamiento original, pero lo adapta al nuevo pipeline modular. fileciteturn10file3turn10file4

## 4. Convención estandarizada de nombres de tablas

Se adopta la convención:

```text
<dataset>_<producto>_<stage>
```

donde:

- `<dataset>` identifica el origen: `art`, `ctd_local`, `ctd_remote`
- `<producto>` identifica el tipo de tabla
- `<stage>` identifica la etapa:
  - `s2` para la capa de gap filling
  - `s3` para la capa de analysis

### Tablas S2, gap filling

Para cada dataset se definen las siguientes tablas:

- `<dataset>_regularized_s2`
- `<dataset>_segment_summary_s2`
- `<dataset>_gapfilled_s2`
- `<dataset>_gapfill_flags_s2`
- `<dataset>_gapfill_validation_s2`
- `<dataset>_gapfill_method_counts_s2`
- `<dataset>_gapfill_summary_s2`

### Tablas S3, analysis

Para cada dataset se definen las siguientes tablas:

- `<dataset>_psd_s3`
- `<dataset>_beta_s3`
- `<dataset>_alpha_s3`
- `<dataset>_fi_s3`
- `<dataset>_graph_s3`
- `<dataset>_regimes_s3`

## 5. Caracterización de la entrada a gap filling

La caracterización de la entrada debe servir como base para definir las tablas bronze o de entrada operativa a S2 en BigQuery.

### 5.1 Dataset `art`

El pipeline modular original esperaba una tabla con columna temporal `TIMESTAMP`, frecuencia de 30 minutos y variables requeridas como `H`, `LE`, `CO2_Flux`, `TA`, `RH`, `VPD`, además de variables opcionales como `RN`, `ET`, `Wind_Speed`, `PPFD`, `RAIN`, `WL`, `TW`, `TS`. Esa estructura está descrita tanto en los configs como en el código modular legado. fileciteturn10file1turn10file2

Campos mínimos recomendados para BigQuery:

- `TIMESTAMP` TIMESTAMP
- `H` FLOAT64
- `LE` FLOAT64
- `CO2_Flux` FLOAT64
- `TA` FLOAT64
- `RH` FLOAT64
- `VPD` FLOAT64

Campos opcionales recomendados:

- `RN` FLOAT64
- `ET` FLOAT64
- `Wind_Speed` FLOAT64
- `PPFD` FLOAT64
- `RAIN` FLOAT64
- `WL` FLOAT64
- `TW` FLOAT64
- `TS` FLOAT64

### 5.2 Dataset `ctd_local`

En la versión actualizada, `ctd_local` ya no debe seguir la configuración vieja del pipeline modular, porque esa configuración antigua esperaba variables como `oxygen` y `ph`, además de frecuencia de 60 minutos. Esa definición quedó desfasada respecto al esquema nuevo. fileciteturn10file1

La tabla de entrada actual para `ctd_local` debe considerar:

- `primary_key` STRING
- `station_id` STRING o INT64
- `date_time` STRING
- `time_zone` STRING
- `timestamp` TIMESTAMP
- `press` FLOAT64
- `temp` FLOAT64
- `spec_cond` FLOAT64

Caracterización:
- la columna temporal operativa es `timestamp`
- la frecuencia de trabajo adoptada en la actualización es 15 minutos
- `press` y `temp` se comportan como variables base
- `spec_cond` es una variable crítica para imputación y análisis

### 5.3 Dataset `ctd_remote`

La configuración vieja del pipeline modular también quedó desfasada para `ctd_remote`, porque seguía esperando variables de otro tipo y frecuencia horaria. fileciteturn10file1 La tabla de entrada actual para `ctd_remote` debe definirse con:

- `primary_key` STRING
- `station_id` STRING o INT64
- `station_name` STRING
- `timestamp` TIMESTAMP
- `dateAndTime` STRING
- `pressure` FLOAT64
- `temperature` FLOAT64
- `conductivity` FLOAT64
- `salinity` FLOAT64
- `level` FLOAT64

Caracterización:
- la columna temporal operativa es `timestamp`
- la frecuencia de trabajo adoptada en la actualización es 15 minutos
- las variables principales del análisis son `pressure`, `temperature`, `conductivity`, `salinity` y `level`

## 6. Caracterización de las salidas S2, gap filling

### 6.1 `<dataset>_regularized_s2`

Propósito:
- conservar la serie temporal regularizada a la frecuencia esperada

Campos esperados:
- columna temporal del dataset
- variables numéricas principales
- metadatos opcionales si se decide arrastrarlos

Uso:
- diagnóstico
- trazabilidad de la malla temporal
- comparación contra la tabla gapfilled

### 6.2 `<dataset>_segment_summary_s2`

Propósito:
- describir la estructura temporal detectada antes y después del tratamiento de huecos

Campos mínimos:
- `segment_id` INT64
- `start_idx` INT64
- `end_idx` INT64
- `n_points` INT64
- `start_time` TIMESTAMP
- `end_time` TIMESTAMP
- `duration_hours` FLOAT64
- `action_taken` STRING
- `is_valid_for_analysis` BOOL
- `dataset_key` STRING
- `mode` STRING
- `run_id` STRING

### 6.3 `<dataset>_gapfilled_s2`

Propósito:
- ser la tabla principal de salida del gap filling
- alimentar directamente la etapa S3

Campos mínimos:
- columna temporal
- variables ya regularizadas y gapfilled
- `segment_id` INT64
- `dataset_key` STRING
- `mode` STRING
- `run_id` STRING

### 6.4 `<dataset>_gapfill_flags_s2`

Propósito:
- conservar trazabilidad por variable y por instante sobre el método aplicado o la ausencia de imputación

Formato recomendado:
- formato largo, no ancho

Campos mínimos:
- columna temporal
- `segment_id`
- `variable`
- `flag`
- `dataset_key`
- `mode`
- `run_id`

Valores típicos de `flag`:
- `observed`
- `imputed_time_limited`
- `imputed_rf`
- `imputed_rf_time_only`
- `left_as_nan_large_gap`
- `left_as_nan_edge_gap`
- `left_as_nan_missing_predictors`

### 6.5 `<dataset>_gapfill_validation_s2`

Propósito:
- guardar métricas de desempeño del gap filling por variable y segmento

Campos mínimos:
- `segment_id`
- `variable`
- `n_trials`
- `n_points_scored`
- `mae`
- `rmse`
- `bias`
- `r2`
- `dataset_key`
- `mode`
- `run_id`

### 6.6 `<dataset>_gapfill_method_counts_s2`

Propósito:
- cuantificar cuánto llenó cada método y cuánto quedó sin imputar

Campos mínimos:
- `segment_id`
- `variable`
- `n_rows`
- `missing_before`
- `missing_after`
- `filled_total`
- `filled_time_limited`
- `filled_rf`
- `filled_rf_time_only`
- `left_as_nan_large_gap`
- `left_as_nan_edge_gap`
- `left_as_nan_missing_predictors`
- `dataset_key`
- `mode`
- `run_id`

### 6.7 `<dataset>_gapfill_summary_s2`

Propósito:
- tabla resumen unificada para monitoreo, auditoría técnica y dashboards de control interno

Campos mínimos:
- todos los campos de `gapfill_method_counts`
- más `mae`, `rmse`, `bias`, `r2`
- `dataset_key`
- `mode`
- `run_id`

## 7. Caracterización de las salidas S3, analysis

### 7.1 `<dataset>_psd_s3`

Propósito:
- persistir la densidad espectral de potencia en formato largo

El pipeline legado ya definía `df_psd` como una de las seis tablas persistibles principales del análisis. fileciteturn10file3turn10file4

Campos mínimos:
- `segment_id`
- `variable`
- `frequency`
- `power`
- `n_points`
- `nperseg`
- `sampling_frequency`
- `dataset_key`
- `mode`
- `run_id`

### 7.2 `<dataset>_beta_s3`

Propósito:
- resumen espectral por variable

Campos mínimos:
- `segment_id`
- `variable`
- `beta`
- `r2`
- `n_points`
- `interpretation`
- `dataset_key`
- `mode`
- `run_id`

### 7.3 `<dataset>_alpha_s3`

Propósito:
- resumen PCA por grupo de variables

Campos mínimos:
- `segment_id`
- `group`
- `alpha`
- `r2`
- `n_obs`
- `n_vars`
- `interpretation`
- `dataset_key`
- `mode`
- `run_id`

### 7.4 `<dataset>_fi_s3`

Propósito:
- persistir Fisher Information multivariada por ventana temporal

Campos mínimos:
- columna temporal
- `segment_id`
- `FI`
- `FI2`
- `n_states`
- `entropy`
- `n_samples_window`
- `coverage_pct`
- `dataset_key`
- `mode`
- `run_id`

### 7.5 `<dataset>_graph_s3`

Propósito:
- persistir métricas dinámicas del grafo funcional

Campos mínimos:
- columna temporal
- `segment_id`
- `mean_connectivity`
- `total_strength`
- `link_density`
- `n_strong_links` o `strong_links`
- `dataset_key`
- `mode`
- `run_id`

### 7.6 `<dataset>_regimes_s3`

Propósito:
- persistir la clasificación temporal de regímenes

Campos mínimos:
- columna temporal
- `segment_id`
- `FI`
- `mean_connectivity`
- `link_density`
- `regime`
- `dataset_key`
- `mode`
- `run_id`

## 8. Patrón de integración actualizado

El patrón anterior, basado en una sola llamada a `transform_timeseries`, estaba bien para el diseño viejo, pero ya no es suficiente para el pipeline modular nuevo. Ese patrón todavía aparece en el ejemplo mínimo y en la documentación del pipeline legado. fileciteturn10file0turn10file2turn10file3

El patrón actualizado debe quedar así.

### 8.1 Etapa S2

```python
df_bronze = read_from_big_query("<dataset>_bronze")

gapfill_outputs = run_gapfill(df_bronze, gapfill_config)

write_to_big_query(gapfill_outputs["regularized"], "<dataset>_regularized_s2")
write_to_big_query(gapfill_outputs["segment_summary"], "<dataset>_segment_summary_s2")
write_to_big_query(gapfill_outputs["gapfilled"], "<dataset>_gapfilled_s2")
write_to_big_query(gapfill_outputs["flags"], "<dataset>_gapfill_flags_s2")
write_to_big_query(gapfill_outputs["validation"], "<dataset>_gapfill_validation_s2")
write_to_big_query(gapfill_outputs["method_counts"], "<dataset>_gapfill_method_counts_s2")
write_to_big_query(gapfill_outputs["summary"], "<dataset>_gapfill_summary_s2")
```

### 8.2 Etapa S3

```python
df_gapfilled = read_from_big_query("<dataset>_gapfilled_s2")
df_segments = read_from_big_query("<dataset>_segment_summary_s2")

for segment_id in valid_segments(df_segments):
    df_segment = df_gapfilled[df_gapfilled["segment_id"] == segment_id]
    analysis_outputs = run_analysis(df_segment, analysis_config)

    write_to_big_query(analysis_outputs["psd"], "<dataset>_psd_s3")
    write_to_big_query(analysis_outputs["beta"], "<dataset>_beta_s3")
    write_to_big_query(analysis_outputs["alpha"], "<dataset>_alpha_s3")
    write_to_big_query(analysis_outputs["fi"], "<dataset>_fi_s3")
    write_to_big_query(analysis_outputs["graph"], "<dataset>_graph_s3")
    write_to_big_query(analysis_outputs["regimes"], "<dataset>_regimes_s3")
```

## 9. Conjunto de archivos que cumple con este diseño actualizado

El conjunto mínimo de archivos para dejar funcional la estructura de transferencia a la nube es el siguiente:

```text
cloud_transfer_update/
  README_cloud_transfer_update.md

  integration/
    bq_io.py
    orchestration.py
    table_naming.py
    schema_contracts.py
    config_resolver.py

  gapfill/
    art_gapfill.py
    ctd_local_gapfill.py
    ctd_remote_gapfill.py

  analysis/
    art_analysis.py
    ctd_local_analysis.py
    ctd_remote_analysis.py

  configs/
    art_gapfill_lite.yaml
    art_gapfill_full.yaml
    art_analysis_lite.yaml
    art_analysis_full.yaml

    ctd_local_gapfill_lite.yaml
    ctd_local_gapfill_full.yaml
    ctd_local_analysis_lite.yaml
    ctd_local_analysis_full.yaml

    ctd_remote_gapfill_lite.yaml
    ctd_remote_gapfill_full.yaml
    ctd_remote_analysis_lite.yaml
    ctd_remote_analysis_full.yaml

  examples/
    example_run_art.py
    example_run_ctd_local.py
    example_run_ctd_remote.py
```

## 10. Rol de cada archivo

### `README_cloud_transfer_update.md`
Documento maestro del contrato técnico actualizado.

### `bq_io.py`
Solo lectura y escritura en BigQuery.

### `table_naming.py`
Única fuente para construir nombres como:
- `art_gapfilled_s2`
- `ctd_local_psd_s3`
- `ctd_remote_regimes_s3`

### `schema_contracts.py`
Define la estructura esperada de:
- entrada a S2
- salidas S2
- salidas S3

### `config_resolver.py`
Resuelve el YAML correcto según:
- dataset
- stage
- mode

### `orchestration.py`
Orquesta el workflow completo:
- lectura bronze
- ejecución de gap filling
- persistencia S2
- lectura S2
- ejecución de analysis
- persistencia S3

### `gapfill/*.py`
Puntos de entrada de la etapa S2 por dataset.

### `analysis/*.py`
Puntos de entrada de la etapa S3 por dataset.

### `configs/*.yaml`
Configuraciones `lite` y `full` por dataset y por etapa.

### `examples/*.py`
Ejemplos mínimos de integración punta a punta para cada dataset.

## 11. Próximo paso

El siguiente paso operativo es generar los archivos de la carpeta `integration/`, empezando por:

1. `table_naming.py`
2. `schema_contracts.py`
3. `config_resolver.py`
4. `orchestration.py`

Ese bloque ya dejaría la actualización de nube encaminada de forma funcional.

## 12. Estado actual de implementación

A la fecha, la actualización ya no se encuentra solo a nivel conceptual. Ya existe una primera base implementada dentro de la carpeta `integration/`, alineada con el diseño descrito en este documento.

### 12.1 Módulos ya construidos

#### `table_naming.py`

Este módulo ya implementa la convención de nombres de tablas descrita en este README. Su función es validar:

- `dataset`
- `product`
- `stage`

y construir nombres estandarizados del tipo:

- `art_gapfilled_s2`
- `ctd_local_psd_s3`
- `ctd_remote_regimes_s3`

También incluye utilidades para construir de una sola vez todos los nombres de tablas S2 o S3 asociados a un dataset.

#### `schema_contracts.py`

Este módulo ya traduce la caracterización funcional y tabular descrita en este README a contratos de esquema programáticos. En particular, incluye:

- esquemas bronze esperados por dataset,
- esquemas S2 esperados por producto,
- esquemas S3 esperados por producto,
- columnas comunes para trazabilidad (`dataset_key`, `mode`, `run_id`, `segment_id`),
- utilidades para producir listas de campos compatibles con la definición de tablas en BigQuery.

Con esto, el documento deja de ser únicamente descriptivo y pasa a tener una contraparte directamente usable por la capa de integración.

#### `config_resolver.py`

Este módulo ya permite resolver de forma programática el archivo de configuración correcto según:

- `dataset`
- `stage`
- `mode`

y también localizar el script correspondiente. El objetivo es evitar rutas rígidas o lógica manual dispersa dentro del orquestador de nube.

#### `bq_io.py`

Este módulo define los placeholders mínimos de lectura y escritura hacia BigQuery. Su propósito es fijar el contrato de I/O para el equipo integrador sin mezclar la lógica científica con el acceso a datos. Debe contener, al menos:

- `read_from_big_query(...)`
- `write_to_big_query(...)`
- una verificación mínima de que las salidas son tabulares y escribibles

### 12.1.1 Ajuste adicional requerido en analysis

Para que la tabla `<dataset>_psd_s3` quede completamente cubierta por el orquestador, los scripts de `analysis` deben exportar explícitamente la PSD en formato largo, por ejemplo como `psd_long.csv`. Esta salida ya es consistente con el contrato analítico previo, donde la PSD era una de las tablas persistibles recomendadas. fileciteturn10file3turn10file4

### 12.2 Módulos todavía pendientes

El módulo principal que falta para cerrar la actualización funcional es:

#### `orchestration.py`

Este archivo debe convertirse en la pieza operativa que una todo lo anterior. Su responsabilidad será:

- leer desde BigQuery,
- resolver la configuración correcta,
- invocar el script de `gapfill` correspondiente,
- persistir las tablas S2,
- recuperar la tabla `*_gapfilled_s2` y la tabla `*_segment_summary_s2`,
- iterar por `segment_id` válido,
- invocar el script de `analysis`,
- persistir las tablas S3.

### 12.3 Estado del diseño

Por lo tanto, el diseño ya cuenta con tres niveles de avance:

1. **documentación contractual**, ya contenida en este README,
2. **módulos base de integración**, ya implementados en `integration/`,
3. **orquestación operativa**, todavía pendiente.

## 13. Próximo paso recomendado

El siguiente paso de desarrollo debe ser construir `orchestration.py` con un flujo punta a punta de la forma:

```python
df_bronze = read_from_big_query("<dataset>_bronze")

gapfill_outputs = run_gapfill_stage(df_bronze, dataset, mode)
persist_s2_outputs(gapfill_outputs)

df_gapfilled = read_from_big_query("<dataset>_gapfilled_s2")
df_segments = read_from_big_query("<dataset>_segment_summary_s2")

for segment_id in valid_segments(df_segments):
    df_segment = df_gapfilled[df_gapfilled["segment_id"] == segment_id]
    analysis_outputs = run_analysis_stage(df_segment, dataset, mode, segment_id)
    persist_s3_outputs(analysis_outputs)
```

Ese archivo, junto con la capa real de lectura y escritura a BigQuery, cerraría la actualización del esquema de transferencia a la nube.

## 14. Relación entre este README y la implementación

Este README debe entenderse como el documento maestro del contrato técnico. Los módulos de `integration/` no sustituyen este documento, sino que lo implementan parcialmente. Toda modificación futura del contrato de tablas, convención de nombres o trazabilidad debe reflejarse primero aquí y después en:

- `table_naming.py`
- `schema_contracts.py`
- `config_resolver.py`
- `orchestration.py`

## 15. Estructura final de carpetas

La estructura final recomendada y ya preparada en esta actualización es la siguiente:

```text
cloud_transfer_update/
  README_cloud_transfer_update.md

  integration/
    bq_io.py
    orchestration.py
    table_naming.py
    schema_contracts.py
    config_resolver.py

  gapfill/
    art_gapfill.py
    ctd_local_gapfill.py
    ctd_remote_gapfill.py

  analysis/
    art_analysis.py
    ctd_local_analysis.py
    ctd_remote_analysis.py

  configs/
    art_gapfill_lite.yaml
    art_gapfill_full.yaml
    art_analysis_lite.yaml
    art_analysis_full.yaml

    ctd_local_gapfill_lite.yaml
    ctd_local_gapfill_full.yaml
    ctd_local_analysis_lite.yaml
    ctd_local_analysis_full.yaml

    ctd_remote_gapfill_lite.yaml
    ctd_remote_gapfill_full.yaml
    ctd_remote_analysis_lite.yaml
    ctd_remote_analysis_full.yaml

  examples/
    example_run_art.py
    example_run_ctd_local.py
    example_run_ctd_remote.py
```

### 15.1 Qué contiene cada carpeta

#### `integration/`
Contiene la capa de integración con la nube. Aquí se concentran la nomenclatura de tablas, los contratos de esquema, la resolución de configuraciones, los stubs de BigQuery y el orquestador punta a punta.

#### `gapfill/`
Contiene los puntos de entrada de la etapa S2 para cada dataset soportado. Cada script recibe un `DataFrame` bronze materializado temporalmente en CSV por el orquestador, aplica regularización y llenado de huecos, y produce las tablas S2.

#### `analysis/`
Contiene los puntos de entrada de la etapa S3 para cada dataset soportado. Cada script consume los segmentos listos para análisis producidos por S2 y exporta las tablas analíticas persistibles, incluyendo `psd_long.csv` para cubrir la tabla `<dataset>_psd_s3`.

#### `configs/`
Contiene todas las configuraciones operativas en YAML, organizadas por dataset, etapa y modo. Esta carpeta sustituye el papel operativo que antes cumplía un diccionario rígido de configuraciones internas. Las funciones de integración deben resolver siempre las configs desde aquí.

#### `examples/`
Contiene ejemplos mínimos de ejecución punta a punta para cada dataset. Estos ejemplos sirven como referencia para el equipo integrador y como base para pruebas de aceptación.

### 15.2 Estado actual del empaquetado

Con esta estructura, la actualización ya no está dispersa en varios directorios de trabajo. Queda reunida en un solo árbol lógico que permite:

- ubicar rápidamente los scripts de S2 y S3,
- resolver las configuraciones correctas,
- integrar el orquestador con BigQuery,
- y ejecutar pruebas por dataset sin reacomodos manuales adicionales.

## 16. Próximo paso operativo

El siguiente paso recomendado después de consolidar esta estructura es ejecutar una prueba punta a punta simulada con un stub de BigQuery o con tablas de prueba reales. Esa prueba debe verificar, para al menos un dataset:

1. lectura desde bronze,
2. ejecución de S2,
3. persistencia de tablas `*_s2`,
4. lectura de `*_gapfilled_s2` y `*_segment_summary_s2`,
5. ejecución de S3,
6. persistencia de tablas `*_s3`.

Una vez validado ese flujo en un caso, el mismo patrón debe repetirse para `art`, `ctd_local` y `ctd_remote`.

## 17. Validación simulada punta a punta

La estructura consolidada ya fue probada mediante una simulación de BigQuery usando funciones stub de lectura y escritura. Bajo esa prueba, el flujo completo fue validado en modo `lite` para los tres datasets soportados:

- `art`
- `ctd_local`
- `ctd_remote`

En los tres casos se verificó el siguiente patrón:

1. lectura de tabla bronze,
2. ejecución de la etapa S2,
3. persistencia de tablas `*_s2`,
4. lectura de `*_gapfilled_s2` y `*_segment_summary_s2`,
5. ejecución de la etapa S3,
6. persistencia de tablas `*_s3`.

## 18. Criterio operativo común para `lite` y `full`

Para evitar que la integración en nube falle por la generación de figuras pesadas, todos los archivos de configuración en la estructura final incluyen ahora el parámetro:

```yaml
generate_figures: false
```

Ese criterio se aplica tanto a configuraciones `lite` como `full` dentro del paquete de transferencia a la nube. La razón es operativa: en el flujo cloud, las figuras no forman parte del contrato de persistencia y solo añaden costo computacional. El pipeline sigue produciendo todas las tablas S2 y S3 relevantes, pero omite la generación de imágenes cuando se usa esta estructura final de integración.

Si en algún momento se desea reactivar la producción de figuras para depuración local, basta con cambiar ese parámetro a `true` en el YAML correspondiente.
