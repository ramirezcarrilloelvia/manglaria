from __future__ import annotations

from dataclasses import dataclass

VALID_DATASETS = {"art", "ctd_local", "ctd_remote"}
VALID_STAGES = {"s2", "s3"}

S2_PRODUCTS = {
    "regularized",
    "segment_summary",
    "gapfilled",
    "gapfill_flags",
    "gapfill_validation",
    "gapfill_method_counts",
    "gapfill_summary",
}

S3_PRODUCTS = {
    "psd",
    "beta",
    "alpha",
    "fi",
    "graph",
    "regimes",
}


@dataclass(frozen=True)
class TableContext:
    dataset: str
    product: str
    stage: str


def validate_dataset(dataset: str) -> str:
    if dataset not in VALID_DATASETS:
        raise ValueError(f"Dataset no soportado: {dataset!r}. Válidos: {sorted(VALID_DATASETS)}")
    return dataset


def validate_stage(stage: str) -> str:
    if stage not in VALID_STAGES:
        raise ValueError(f"Stage no soportado: {stage!r}. Válidos: {sorted(VALID_STAGES)}")
    return stage


def validate_product(product: str, stage: str) -> str:
    stage = validate_stage(stage)
    valid_products = S2_PRODUCTS if stage == "s2" else S3_PRODUCTS
    if product not in valid_products:
        raise ValueError(
            f"Producto no soportado para {stage}: {product!r}. "
            f"Válidos: {sorted(valid_products)}"
        )
    return product


def build_table_name(dataset: str, product: str, stage: str) -> str:
    dataset = validate_dataset(dataset)
    stage = validate_stage(stage)
    product = validate_product(product, stage)
    return f"{dataset}_{product}_{stage}"


def build_all_table_names(dataset: str) -> dict[str, str]:
    dataset = validate_dataset(dataset)

    names = {}
    for product in sorted(S2_PRODUCTS):
        names[f"{product}_s2"] = build_table_name(dataset, product, "s2")
    for product in sorted(S3_PRODUCTS):
        names[f"{product}_s3"] = build_table_name(dataset, product, "s3")
    return names


def build_gapfill_table_names(dataset: str) -> dict[str, str]:
    dataset = validate_dataset(dataset)
    return {product: build_table_name(dataset, product, "s2") for product in sorted(S2_PRODUCTS)}


def build_analysis_table_names(dataset: str) -> dict[str, str]:
    dataset = validate_dataset(dataset)
    return {product: build_table_name(dataset, product, "s3") for product in sorted(S3_PRODUCTS)}


if __name__ == "__main__":
    for ds in sorted(VALID_DATASETS):
        print(ds)
        for key, value in build_all_table_names(ds).items():
            print(f"  {key}: {value}")
