from __future__ import annotations

from dataclasses import dataclass
from typing import Iterable

BRONZE_SCHEMAS = {
    "art": {
        "required": {
            "TIMESTAMP": "TIMESTAMP",
            "H": "FLOAT64",
            "LE": "FLOAT64",
            "CO2_Flux": "FLOAT64",
            "TA": "FLOAT64",
            "RH": "FLOAT64",
            "VPD": "FLOAT64",
        },
        "optional": {
            "RN": "FLOAT64",
            "ET": "FLOAT64",
            "Wind_Speed": "FLOAT64",
            "PPFD": "FLOAT64",
            "RAIN": "FLOAT64",
            "WL": "FLOAT64",
            "TW": "FLOAT64",
            "TS": "FLOAT64",
        },
    },
    "ctd_local": {
        "required": {
            "timestamp": "TIMESTAMP",
            "press": "FLOAT64",
            "temp": "FLOAT64",
            "spec_cond": "FLOAT64",
        },
        "optional": {
            "primary_key": "STRING",
            "station_id": "STRING",
            "date_time": "STRING",
            "time_zone": "STRING",
        },
    },
    "ctd_remote": {
        "required": {
            "timestamp": "TIMESTAMP",
            "pressure": "FLOAT64",
            "temperature": "FLOAT64",
            "conductivity": "FLOAT64",
            "salinity": "FLOAT64",
            "level": "FLOAT64",
        },
        "optional": {
            "primary_key": "STRING",
            "station_id": "STRING",
            "station_name": "STRING",
            "dateAndTime": "STRING",
        },
    },
}

S2_COMMON = {
    "dataset_key": "STRING",
    "mode": "STRING",
    "run_id": "STRING",
}

S3_COMMON = {
    "dataset_key": "STRING",
    "mode": "STRING",
    "run_id": "STRING",
    "segment_id": "INT64",
}

S2_SCHEMAS = {
    "regularized": {},
    "segment_summary": {
        "segment_id": "INT64",
        "start_idx": "INT64",
        "end_idx": "INT64",
        "n_points": "INT64",
        "start_time": "TIMESTAMP",
        "end_time": "TIMESTAMP",
        "duration_hours": "FLOAT64",
        "action_taken": "STRING",
        "is_valid_for_analysis": "BOOL",
        **S2_COMMON,
    },
    "gapfilled": {
        "segment_id": "INT64",
        **S2_COMMON,
    },
    "gapfill_flags": {
        "variable": "STRING",
        "flag": "STRING",
        "segment_id": "INT64",
        **S2_COMMON,
    },
    "gapfill_validation": {
        "segment_id": "INT64",
        "variable": "STRING",
        "n_trials": "INT64",
        "n_points_scored": "INT64",
        "mae": "FLOAT64",
        "rmse": "FLOAT64",
        "bias": "FLOAT64",
        "r2": "FLOAT64",
        **S2_COMMON,
    },
    "gapfill_method_counts": {
        "segment_id": "INT64",
        "variable": "STRING",
        "n_rows": "INT64",
        "missing_before": "INT64",
        "missing_after": "INT64",
        "filled_total": "INT64",
        "filled_time_limited": "INT64",
        "filled_rf": "INT64",
        "filled_rf_time_only": "INT64",
        "left_as_nan_large_gap": "INT64",
        "left_as_nan_edge_gap": "INT64",
        "left_as_nan_missing_predictors": "INT64",
        **S2_COMMON,
    },
    "gapfill_summary": {
        "segment_id": "INT64",
        "variable": "STRING",
        "n_rows": "INT64",
        "missing_before": "INT64",
        "missing_after": "INT64",
        "filled_total": "INT64",
        "filled_time_limited": "INT64",
        "filled_rf": "INT64",
        "filled_rf_time_only": "INT64",
        "left_as_nan_large_gap": "INT64",
        "left_as_nan_edge_gap": "INT64",
        "left_as_nan_missing_predictors": "INT64",
        "n_trials": "INT64",
        "n_points_scored": "INT64",
        "mae": "FLOAT64",
        "rmse": "FLOAT64",
        "bias": "FLOAT64",
        "r2": "FLOAT64",
        **S2_COMMON,
    },
}

S3_SCHEMAS = {
    "psd": {
        "variable": "STRING",
        "frequency": "FLOAT64",
        "power": "FLOAT64",
        "n_points": "INT64",
        "nperseg": "INT64",
        "sampling_frequency": "FLOAT64",
        **S3_COMMON,
    },
    "beta": {
        "variable": "STRING",
        "beta": "FLOAT64",
        "r2": "FLOAT64",
        "n_points": "INT64",
        "interpretation": "STRING",
        **S3_COMMON,
    },
    "alpha": {
        "group": "STRING",
        "alpha": "FLOAT64",
        "r2": "FLOAT64",
        "n_obs": "INT64",
        "n_vars": "INT64",
        "interpretation": "STRING",
        **S3_COMMON,
    },
    "fi": {
        "FI": "FLOAT64",
        "FI2": "FLOAT64",
        "n_states": "INT64",
        "entropy": "FLOAT64",
        "n_samples_window": "INT64",
        "coverage_pct": "FLOAT64",
        **S3_COMMON,
    },
    "graph": {
        "mean_connectivity": "FLOAT64",
        "total_strength": "FLOAT64",
        "link_density": "FLOAT64",
        "n_strong_links": "INT64",
        **S3_COMMON,
    },
    "regimes": {
        "FI": "FLOAT64",
        "mean_connectivity": "FLOAT64",
        "link_density": "FLOAT64",
        "regime": "INT64",
        **S3_COMMON,
    },
}

TIME_COLUMN_BY_DATASET = {
    "art": "TIMESTAMP",
    "ctd_local": "timestamp",
    "ctd_remote": "timestamp",
}


def get_bronze_schema(dataset: str) -> dict[str, dict[str, str]]:
    if dataset not in BRONZE_SCHEMAS:
        raise ValueError(f"Dataset no soportado: {dataset!r}")
    return BRONZE_SCHEMAS[dataset]


def get_s2_schema(product: str) -> dict[str, str]:
    if product not in S2_SCHEMAS:
        raise ValueError(f"Producto S2 no soportado: {product!r}")
    return S2_SCHEMAS[product]


def get_s3_schema(product: str) -> dict[str, str]:
    if product not in S3_SCHEMAS:
        raise ValueError(f"Producto S3 no soportado: {product!r}")
    return S3_SCHEMAS[product]


def add_time_column(schema: dict[str, str], dataset: str) -> dict[str, str]:
    out = dict(schema)
    time_col = TIME_COLUMN_BY_DATASET[dataset]
    if time_col not in out:
        out = {time_col: "TIMESTAMP", **out}
    return out


def expected_table_schema(dataset: str, product: str, stage: str) -> dict[str, str]:
    if stage == "s2":
        base = get_s2_schema(product)
    elif stage == "s3":
        base = get_s3_schema(product)
    else:
        raise ValueError(f"Stage no soportado: {stage!r}")
    return add_time_column(base, dataset)


def to_bq_field_list(schema: dict[str, str]) -> list[dict[str, str]]:
    return [{"name": name, "type": typ, "mode": "NULLABLE"} for name, typ in schema.items()]


if __name__ == "__main__":
    for dataset in ["art", "ctd_local", "ctd_remote"]:
        print(f"\nDataset: {dataset}")
        print("Bronze required:", BRONZE_SCHEMAS[dataset]["required"])
        print("gapfilled_s2:", expected_table_schema(dataset, "gapfilled", "s2"))
        print("psd_s3:", expected_table_schema(dataset, "psd", "s3"))
