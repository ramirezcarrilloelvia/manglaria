from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Callable
import importlib.util
import uuid
import pandas as pd

from table_naming import build_gapfill_table_names, build_analysis_table_names, build_table_name
from config_resolver import resolve_config_path, resolve_script_path


ReadFn = Callable[[str], pd.DataFrame]
WriteFn = Callable[[pd.DataFrame, str], None]

PATCHED_ANALYSIS_SCRIPT_MAP = {
    "art": "flujo_eddycovariant_analysis_patched.py",
    "ctd_local": "ctd_local_analysis_patched.py",
    "ctd_remote": "ctd_remote_analysis_patched.py",
}


@dataclass
class OrchestrationContext:
    dataset: str
    mode: str
    run_id: str
    config_root: Path
    gapfill_scripts_root: Path
    analysis_scripts_root: Path


def _load_module_from_path(module_path: Path):
    module_name = f"dynamic_{module_path.stem}_{uuid.uuid4().hex[:8]}"
    spec = importlib.util.spec_from_file_location(module_name, module_path)
    if spec is None or spec.loader is None:
        raise ImportError(f"No se pudo cargar el módulo desde {module_path}")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def _require_run_pipeline(module, script_path: Path):
    if not hasattr(module, "run_pipeline"):
        raise AttributeError(f"El script {script_path} no expone una función run_pipeline(config_path)")
    return module.run_pipeline


def _enrich_metadata(df: pd.DataFrame, dataset: str, mode: str, run_id: str, segment_id: int | None = None) -> pd.DataFrame:
    out = df.copy()
    if "dataset_key" not in out.columns:
        out["dataset_key"] = dataset
    if "mode" not in out.columns:
        out["mode"] = mode
    if "run_id" not in out.columns:
        out["run_id"] = run_id
    if segment_id is not None and "segment_id" not in out.columns:
        out["segment_id"] = segment_id
    return out


def _persist_if_exists(
    path: Path,
    table_name: str,
    read_csv_kwargs: dict,
    write_to_bigquery: WriteFn,
    dataset: str,
    mode: str,
    run_id: str,
    segment_id: int | None = None,
) -> None:
    if not path.exists():
        return
    df = pd.read_csv(path, **read_csv_kwargs)
    df = _enrich_metadata(df, dataset=dataset, mode=mode, run_id=run_id, segment_id=segment_id)
    write_to_bigquery(df, table_name)


def _resolve_analysis_script(dataset: str, analysis_scripts_root: Path) -> Path:
    if dataset not in PATCHED_ANALYSIS_SCRIPT_MAP:
        raise ValueError(f"No hay script patched definido para dataset {dataset!r}")
    script_path = analysis_scripts_root / PATCHED_ANALYSIS_SCRIPT_MAP[dataset]
    if not script_path.exists():
        raise FileNotFoundError(f"No se encontró el script patched de analysis: {script_path}")
    return script_path


def run_gapfill_stage_from_bq(
    *,
    dataset: str,
    mode: str,
    read_from_bigquery: ReadFn,
    write_to_bigquery: WriteFn,
    bronze_table_name: str,
    config_root: str | Path,
    gapfill_scripts_root: str | Path,
) -> dict:
    run_id = uuid.uuid4().hex
    ctx = OrchestrationContext(
        dataset=dataset,
        mode=mode,
        run_id=run_id,
        config_root=Path(config_root),
        gapfill_scripts_root=Path(gapfill_scripts_root),
        analysis_scripts_root=Path("."),
    )

    gapfill_config = resolve_config_path(dataset, "gapfill", mode, ctx.config_root)
    gapfill_script = resolve_script_path(dataset, "gapfill", ctx.gapfill_scripts_root)

    df_bronze = read_from_bigquery(bronze_table_name)

    gapfill_module = _load_module_from_path(gapfill_script)
    run_pipeline = _require_run_pipeline(gapfill_module, gapfill_script)

    import yaml
    cfg = yaml.safe_load(Path(gapfill_config).read_text(encoding="utf-8"))
    runtime_dir = Path("/tmp") / f"cloud_gapfill_{dataset}_{mode}_{run_id}"
    runtime_dir.mkdir(parents=True, exist_ok=True)
    runtime_input_csv = runtime_dir / f"{dataset}_bronze_runtime.csv"
    runtime_config_yaml = runtime_dir / f"{dataset}_gapfill_runtime.yaml"

    df_bronze.to_csv(runtime_input_csv, index=False)
    cfg["input_csv"] = str(runtime_input_csv)
    cfg["output_dir"] = str(runtime_dir / "outputs")
    runtime_config_yaml.write_text(yaml.safe_dump(cfg, sort_keys=False, allow_unicode=True), encoding="utf-8")

    run_pipeline(runtime_config_yaml)

    table_names = build_gapfill_table_names(dataset)
    outdir = Path(cfg["output_dir"])

    file_map = {
        "regularized": outdir / f"{dataset}_regularized.csv",
        "segment_summary": outdir / f"{dataset}_segment_summary.csv",
        "gapfilled": outdir / f"{dataset}_gapfilled_all_segments.csv",
        "gapfill_flags": outdir / f"{dataset}_gapfill_flags.csv",
        "gapfill_validation": outdir / f"{dataset}_gapfill_validation_summary.csv",
        "gapfill_method_counts": outdir / f"{dataset}_gapfill_method_counts.csv",
        "gapfill_summary": outdir / f"{dataset}_gapfill_summary_combined.csv",
    }

    for product, path in file_map.items():
        _persist_if_exists(
            path=path,
            table_name=table_names[product],
            read_csv_kwargs={},
            write_to_bigquery=write_to_bigquery,
            dataset=dataset,
            mode=mode,
            run_id=run_id,
        )

    return {
        "run_id": run_id,
        "runtime_output_dir": str(outdir),
        "table_names": table_names,
        "analysis_ready_dir": str(outdir / "analysis_ready_segments"),
    }


def run_analysis_stage_from_gapfilled_bq(
    *,
    dataset: str,
    mode: str,
    read_from_bigquery: ReadFn,
    write_to_bigquery: WriteFn,
    gapfilled_table_name: str,
    segment_summary_table_name: str,
    config_root: str | Path,
    analysis_scripts_root: str | Path,
) -> dict:
    run_id = uuid.uuid4().hex
    ctx = OrchestrationContext(
        dataset=dataset,
        mode=mode,
        run_id=run_id,
        config_root=Path(config_root),
        gapfill_scripts_root=Path("."),
        analysis_scripts_root=Path(analysis_scripts_root),
    )

    analysis_config = resolve_config_path(dataset, "analysis", mode, ctx.config_root)
    analysis_script = _resolve_analysis_script(dataset, ctx.analysis_scripts_root)

    df_gapfilled = read_from_bigquery(gapfilled_table_name)
    df_segments = read_from_bigquery(segment_summary_table_name)

    if "segment_id" not in df_gapfilled.columns:
        raise ValueError("La tabla gapfilled no contiene la columna segment_id")
    if "segment_id" not in df_segments.columns:
        raise ValueError("La tabla segment_summary no contiene la columna segment_id")

    valid_mask = df_segments["is_valid_for_analysis"] if "is_valid_for_analysis" in df_segments.columns else True
    valid_segments = sorted(
        df_segments.loc[valid_mask == True, "segment_id"].dropna().astype(int).unique().tolist()
    )

    analysis_module = _load_module_from_path(analysis_script)
    run_pipeline = _require_run_pipeline(analysis_module, analysis_script)

    import yaml
    cfg = yaml.safe_load(Path(analysis_config).read_text(encoding="utf-8"))
    runtime_dir = Path("/tmp") / f"cloud_analysis_{dataset}_{mode}_{run_id}"
    runtime_dir.mkdir(parents=True, exist_ok=True)
    runtime_input_dir = runtime_dir / "analysis_ready_segments"
    runtime_input_dir.mkdir(parents=True, exist_ok=True)
    runtime_config_yaml = runtime_dir / f"{dataset}_analysis_runtime.yaml"

    for seg_id in valid_segments:
        df_segment = df_gapfilled.loc[df_gapfilled["segment_id"] == seg_id].copy()
        if df_segment.empty:
            continue
        df_segment.to_csv(runtime_input_dir / f"segment_{seg_id:02d}_analysis_ready.csv", index=False)

    cfg["input_dir"] = str(runtime_input_dir)
    cfg["output_dir"] = str(runtime_dir / "outputs")
    runtime_config_yaml.write_text(yaml.safe_dump(cfg, sort_keys=False, allow_unicode=True), encoding="utf-8")

    run_pipeline(runtime_config_yaml)

    table_names = build_analysis_table_names(dataset)
    outdir = Path(cfg["output_dir"])

    summary_path = outdir / "analysis_run_summary.csv"
    analysis_run_summary = pd.read_csv(summary_path) if summary_path.exists() else pd.DataFrame()

    for segment_row in analysis_run_summary.to_dict(orient="records"):
        segment_name = segment_row["segment_name"]
        try:
            segment_id = int(segment_name.split("_")[1])
        except Exception:
            segment_id = None

        metrics_dir = outdir / segment_name / "metrics"

        file_map = {
            "psd": metrics_dir / "psd_long.csv",
            "beta": metrics_dir / "beta_results.csv",
            "alpha": metrics_dir / "alpha_results.csv",
            "fi": metrics_dir / "fi_multivariate.csv",
            "graph": metrics_dir / "dynamic_graph_metrics.csv",
            "regimes": metrics_dir / "system_regimes.csv",
        }

        for product, path in file_map.items():
            _persist_if_exists(
                path=path,
                table_name=table_names[product],
                read_csv_kwargs={},
                write_to_bigquery=write_to_bigquery,
                dataset=dataset,
                mode=mode,
                run_id=run_id,
                segment_id=segment_id,
            )

    return {
        "run_id": run_id,
        "runtime_output_dir": str(outdir),
        "table_names": table_names,
        "n_segments_processed": len(valid_segments),
        "analysis_script_used": str(analysis_script),
    }


def run_full_cloud_workflow(
    *,
    dataset: str,
    mode: str,
    bronze_table_name: str,
    read_from_bigquery: ReadFn,
    write_to_bigquery: WriteFn,
    config_root: str | Path,
    gapfill_scripts_root: str | Path,
    analysis_scripts_root: str | Path,
) -> dict:
    gapfill_result = run_gapfill_stage_from_bq(
        dataset=dataset,
        mode=mode,
        read_from_bigquery=read_from_bigquery,
        write_to_bigquery=write_to_bigquery,
        bronze_table_name=bronze_table_name,
        config_root=config_root,
        gapfill_scripts_root=gapfill_scripts_root,
    )

    analysis_result = run_analysis_stage_from_gapfilled_bq(
        dataset=dataset,
        mode=mode,
        read_from_bigquery=read_from_bigquery,
        write_to_bigquery=write_to_bigquery,
        gapfilled_table_name=build_table_name(dataset, "gapfilled", "s2"),
        segment_summary_table_name=build_table_name(dataset, "segment_summary", "s2"),
        config_root=config_root,
        analysis_scripts_root=analysis_scripts_root,
    )

    return {
        "gapfill": gapfill_result,
        "analysis": analysis_result,
    }
