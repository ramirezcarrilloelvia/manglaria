from __future__ import annotations

from typing import Optional
import pandas as pd


def read_from_big_query(table_name: str, query: Optional[str] = None) -> pd.DataFrame:
    """Placeholder de lectura desde BigQuery.

    Debe ser sustituida por la implementación real del equipo integrador.
    El contrato esperado es que devuelva un pandas.DataFrame listo para pasar a S2 o S3.
    """
    raise NotImplementedError("Implementar lectura real desde BigQuery.")


def write_to_big_query(df: pd.DataFrame, table_name: str, if_exists: str = "replace") -> None:
    """Placeholder de escritura hacia BigQuery.

    Debe ser sustituida por la implementación real del equipo integrador.
    El contrato esperado es que escriba el DataFrame sin modificar la lógica científica
    ni reestructurar manualmente las salidas del pipeline.
    """
    raise NotImplementedError("Implementar escritura real hacia BigQuery.")


def assert_bq_ready(df: pd.DataFrame, table_name: str) -> None:
    """Verificación mínima previa a la escritura."""
    if not isinstance(df, pd.DataFrame):
        raise TypeError(f"{table_name}: la salida no es un pandas.DataFrame")
    if df.empty:
        raise ValueError(f"{table_name}: el DataFrame está vacío")
    if isinstance(df.columns, pd.MultiIndex):
        raise ValueError(f"{table_name}: no se permiten columnas MultiIndex")
