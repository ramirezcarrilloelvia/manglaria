from __future__ import annotations

from pathlib import Path

VALID_DATASETS = {"art", "ctd_local", "ctd_remote"}
VALID_STAGES = {"gapfill", "analysis"}
VALID_MODES = {"lite", "full"}


def validate_dataset(dataset: str) -> str:
    if dataset not in VALID_DATASETS:
        raise ValueError(f"Dataset no soportado: {dataset!r}. Válidos: {sorted(VALID_DATASETS)}")
    return dataset


def validate_stage(stage: str) -> str:
    if stage not in VALID_STAGES:
        raise ValueError(f"Stage no soportado: {stage!r}. Válidos: {sorted(VALID_STAGES)}")
    return stage


def validate_mode(mode: str) -> str:
    if mode not in VALID_MODES:
        raise ValueError(f"Modo no soportado: {mode!r}. Válidos: {sorted(VALID_MODES)}")
    return mode


def resolve_config_path(
    dataset: str,
    stage: str,
    mode: str,
    config_root: str | Path,
) -> Path:
    dataset = validate_dataset(dataset)
    stage = validate_stage(stage)
    mode = validate_mode(mode)

    config_root = Path(config_root)
    filename = f"{dataset}_{stage}_{mode}.yaml"
    config_path = config_root / filename

    if not config_path.exists():
        raise FileNotFoundError(f"No se encontró el archivo de configuración: {config_path}")

    return config_path


def resolve_script_path(
    dataset: str,
    stage: str,
    scripts_root: str | Path,
) -> Path:
    dataset = validate_dataset(dataset)
    stage = validate_stage(stage)

    scripts_root = Path(scripts_root)
    filename = f"{dataset}_{stage}.py"
    script_path = scripts_root / filename

    if not script_path.exists():
        raise FileNotFoundError(f"No se encontró el script: {script_path}")

    return script_path


if __name__ == "__main__":
    example_root = Path("/mnt/data/cloud_transfer_update")
    print(resolve_config_path("ctd_local", "gapfill", "lite", example_root / "configs"))
